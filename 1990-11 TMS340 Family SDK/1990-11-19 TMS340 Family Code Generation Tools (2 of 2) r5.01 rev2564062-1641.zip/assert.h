/********************************************************************/
/* assert.h V5.01                                                   */
/* Copyright (c) 1990 Texas Instruments Inc.                        */
/********************************************************************/
#ifndef _ASSERT
#define _ASSERT

#ifdef NDEBUG
#define assert(_ignore)
#else
#define assert(_expr) \
if (!(_expr)) { printf("Assertion failed, (_expr), file %s, line %d\n", \
	       __FILE__, __LINE__); abort();                          }
#endif
#endif

