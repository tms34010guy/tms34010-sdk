/****************************************************************************/
/*  setjmp.h v5.01                                                          */
/*  Copyright (c) 1990 Texas Instruments Inc.                               */
/****************************************************************************/
#ifndef _SETJMP
#define _SETJMP

#if _TMS34082
typedef long jmp_buf[16 + 18];
#else
typedef long jmp_buf[16];
#endif

#define setjmp(_x) _setjmp(_x)
int longjmp();

#endif

