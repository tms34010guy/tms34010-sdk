			TMS340 Family C Source Debugger
				TMDX 5.00

This disk contains two directories: \EMU34020 (which contains a 340 C
Debugger software to be used with the TMS34020 Emulator) and \SDB
(which contains a 340 C Debugger for use with any 340 Development
Board for which a TIGA Communications Driver is available, including
the TMS34020 Software Development Board and TMS34010 TIGA Development
Board).  Read the TMS340 Family C Source Debugger User's Guide for
information on how to install and use these debuggers.

= End of file =


