
struct xxx {
             int         a, b, c;
             int         f1 : 2;
             int         f2 : 4;
             struct xxx *f3;
             int         f4[10];
           };

extern struct xxx str;

call(newvalue)
int newvalue;
{
    static int value = 0;

    switch (newvalue & 3)
    {
        case  0 : str.a = newvalue;      break;
        case  1 : str.b = newvalue + 1;  return;
        case  2 : str.c = newvalue * 2;            /* FALL THROUGH! */
        case  3 : xcall(newvalue);       break;
    }

    value = newvalue;
}

xcall(value)
int value;
{
    str.f1 += str.f2 - value;
}

