struct xxx {
              int         a,b,c;
              int         f1 : 2;
              int         f2 : 4;
              struct xxx *f3;
              int         f4[10];
            } str, astr[10], aastr[9][9], *pastr[10];

union  uuu { int u1, u2, u3, u4, u5[6];
             struct xxx u6;
           } un1, *un2, un3[5];

struct zzz { int b1,b2,b3,b4,b5;
             struct xxx q1[2], q2;
             struct xxx *q3;
           } big1, *big2, big3[6];

struct     { int x,y,z;
             int **ptr;
             float *fptr;
             char ra[5];
           } small;

enum   yyy { RED, GREEN, BLUE } genum, *penum, aenum[5][4][3];
enum       { ONE, TWO, THREE  } e1, *e2, e3[6], e4[2][3][4][5];

struct     { int y,z; } tiny2;
struct     { int x,y,z; } tiny3;
struct     { int w,x,y,z; } tiny4;
struct     { int v,w,x,y,z; } tiny5;
struct     { int u,v,w,x,y,z; } tiny6;

struct bbb { int   a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z;
             float A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z;
             int   very_very_very_very_very_long_name;
           } longstr;

int    i;
short  s;
float  f;
double d;
int    ai[10];
int    aai[10][5];
short  aaas[10][5][2];
char   ac[10];
int    *pi;
char   *xpc;
struct zzz giant[100];

extern  call();
extern  meminit();

main()
{
    register int i = 0;
    int j = 0, k = 0;

    meminit();
    for (i = 0; i < 0x50000; i++)
    {
         call(i);
         if (i & 1) j += i;
         aai[k][k]  = j;
         if (!(i & 0xFFFF)) k++;
    }
    for (;;);
}

